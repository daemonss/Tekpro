package characters;

// Enum untuk status effect (harus public)
public enum StatusEffect {
    POISON, BURN, FREEZE
}